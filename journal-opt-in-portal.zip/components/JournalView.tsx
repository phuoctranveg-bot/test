
import React, { useState, useEffect, useMemo } from 'react';
import { LogOut, Plus, Trash2, Calendar, BookOpen, Loader2, Search, Edit3, X, Check, ArrowRight } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface Entry {
  id: string;
  content: string;
  created_at: string;
  user_id: string;
}

interface JournalViewProps {
  user: any;
  onSignOut: () => void;
  onToast: (msg: string, type: 'success' | 'error') => void;
}

export const JournalView: React.FC<JournalViewProps> = ({ user, onSignOut, onToast }) => {
  const [entries, setEntries] = useState<Entry[]>([]);
  const [newEntry, setNewEntry] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editContent, setEditContent] = useState('');

  useEffect(() => {
    fetchEntries();

    // Set up Realtime Subscription
    const channel = supabase
      .channel('journal_changes')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'journal_entries', filter: `user_id=eq.${user.id}` },
        (payload) => {
          if (payload.eventType === 'INSERT') {
            setEntries((prev) => [payload.new as Entry, ...prev]);
          } else if (payload.eventType === 'DELETE') {
            setEntries((prev) => prev.filter((e) => e.id !== payload.old.id));
          } else if (payload.eventType === 'UPDATE') {
            setEntries((prev) => prev.map((e) => (e.id === payload.new.id ? (payload.new as Entry) : e)));
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user.id]);

  const fetchEntries = async () => {
    setIsLoading(true);
    const { data, error } = await supabase
      .from('journal_entries')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      onToast(error.message, 'error');
    } else {
      setEntries(data || []);
    }
    setIsLoading(false);
  };

  const handleAddEntry = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEntry.trim()) return;

    setIsSubmitting(true);
    const { error } = await supabase
      .from('journal_entries')
      .insert([{ content: newEntry, user_id: user.id }]);

    if (error) {
      onToast(error.message, 'error');
    } else {
      setNewEntry('');
      onToast('Entry saved!', 'success');
      // Realtime handles the list update
    }
    setIsSubmitting(false);
  };

  const handleDeleteEntry = async (id: string) => {
    const { error } = await supabase
      .from('journal_entries')
      .delete()
      .eq('id', id);

    if (error) {
      onToast(error.message, 'error');
    } else {
      onToast('Entry deleted', 'success');
    }
  };

  const startEditing = (entry: Entry) => {
    setEditingId(entry.id);
    setEditContent(entry.content);
  };

  const cancelEditing = () => {
    setEditingId(null);
    setEditContent('');
  };

  const handleUpdateEntry = async (id: string) => {
    if (!editContent.trim()) return;
    
    const { error } = await supabase
      .from('journal_entries')
      .update({ content: editContent })
      .eq('id', id);

    if (error) {
      onToast(error.message, 'error');
    } else {
      onToast('Entry updated', 'success');
      setEditingId(null);
    }
  };

  const filteredEntries = useMemo(() => {
    return entries.filter(entry => 
      entry.content.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [entries, searchQuery]);

  return (
    <div className="w-full max-w-2xl bg-white rounded-3xl shadow-2xl flex flex-col h-[85vh] overflow-hidden animate-slide-up">
      {/* Header */}
      <header className="p-6 border-b border-gray-100 flex items-center justify-between bg-white sticky top-0 z-20">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-sky-500 rounded-xl flex items-center justify-center shadow-lg shadow-sky-200">
            <BookOpen className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="font-bold text-gray-900 leading-tight text-lg">My Journal</h1>
            <p className="text-xs text-gray-400 truncate max-w-[120px] sm:max-w-none">{user.email}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
           <button 
            onClick={onSignOut}
            className="p-2.5 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-xl transition-all"
            title="Sign Out"
          >
            <LogOut className="w-5 h-5" />
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto p-6 space-y-6">
        {/* Entry Form */}
        <form onSubmit={handleAddEntry} className="space-y-3 group">
          <div className="relative">
            <textarea
              value={newEntry}
              onChange={(e) => setNewEntry(e.target.value)}
              placeholder="What's on your mind today?"
              className="w-full min-h-[140px] p-5 rounded-2xl bg-[#2D2D2D] text-white placeholder-gray-500 focus:ring-4 focus:ring-sky-500/10 outline-none transition-all resize-none text-lg border border-transparent focus:border-sky-500/30 shadow-inner"
            />
            <div className="absolute bottom-4 right-4 text-[10px] font-bold text-gray-500 uppercase tracking-widest opacity-0 group-focus-within:opacity-100 transition-opacity">
              {newEntry.length} characters
            </div>
          </div>
          <div className="flex justify-end">
            <button
              disabled={isSubmitting || !newEntry.trim()}
              className="px-6 py-2.5 bg-sky-600 text-white rounded-xl font-semibold shadow-lg shadow-sky-600/20 hover:bg-sky-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center gap-2 active:scale-95"
            >
              {isSubmitting ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Plus className="w-4 h-4" />
              )}
              Save Entry
            </button>
          </div>
        </form>

        {/* Search & List */}
        <div className="space-y-4">
          <div className="flex items-center justify-between px-1">
            <h2 className="text-sm font-bold text-gray-400 uppercase tracking-wider">Your Timeline</h2>
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
              <input 
                type="text"
                placeholder="Search entries..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9 pr-4 py-1.5 bg-gray-50 border border-gray-100 rounded-full text-sm outline-none focus:ring-2 focus:ring-sky-500/10 focus:border-sky-500/20 transition-all w-40 sm:w-60"
              />
            </div>
          </div>

          {isLoading ? (
            <div className="flex flex-col items-center justify-center py-20 gap-3">
              <div className="relative">
                <div className="w-12 h-12 rounded-full border-4 border-sky-100"></div>
                <div className="w-12 h-12 rounded-full border-4 border-t-sky-500 animate-spin absolute top-0 left-0"></div>
              </div>
              <p className="text-sm font-medium text-gray-400">Syncing your journal...</p>
            </div>
          ) : filteredEntries.length === 0 ? (
            <div className="text-center py-16 border-2 border-dashed border-gray-100 rounded-3xl bg-gray-50/50">
              <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-sm">
                <Search className="w-8 h-8 text-gray-200" />
              </div>
              <p className="text-gray-500 font-medium">
                {searchQuery ? 'No matches found for your search' : 'Your journal is empty'}
              </p>
              <p className="text-sm text-gray-400 mt-1">
                {searchQuery ? 'Try a different keyword' : 'Capture your first thought above'}
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {filteredEntries.map((entry) => (
                <div 
                  key={entry.id} 
                  className="group p-5 bg-white border border-gray-100 rounded-2xl hover:border-sky-200 hover:shadow-xl hover:shadow-sky-500/5 transition-all relative overflow-hidden"
                >
                  <div className="flex justify-between items-start mb-3">
                    <div className="flex items-center gap-2 text-[10px] font-bold text-sky-600 bg-sky-50 px-2.5 py-1 rounded-full uppercase tracking-wider">
                      <Calendar className="w-3 h-3" />
                      {new Date(entry.created_at).toLocaleDateString('en-US', {
                        month: 'long',
                        day: 'numeric',
                        year: 'numeric'
                      })}
                    </div>
                    
                    <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      {editingId === entry.id ? (
                        <>
                          <button 
                            onClick={() => handleUpdateEntry(entry.id)}
                            className="p-1.5 text-green-500 hover:bg-green-50 rounded-lg transition-all"
                            title="Save"
                          >
                            <Check className="w-4 h-4" />
                          </button>
                          <button 
                            onClick={cancelEditing}
                            className="p-1.5 text-gray-400 hover:bg-gray-100 rounded-lg transition-all"
                            title="Cancel"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </>
                      ) : (
                        <>
                          <button 
                            onClick={() => startEditing(entry)}
                            className="p-1.5 text-gray-300 hover:text-sky-500 hover:bg-sky-50 rounded-lg transition-all"
                            title="Edit"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                          <button 
                            onClick={() => handleDeleteEntry(entry.id)}
                            className="p-1.5 text-gray-300 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all"
                            title="Delete"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </>
                      )}
                    </div>
                  </div>

                  {editingId === entry.id ? (
                    <textarea
                      autoFocus
                      value={editContent}
                      onChange={(e) => setEditContent(e.target.value)}
                      className="w-full p-4 bg-gray-50 border-2 border-sky-500/20 rounded-xl text-gray-700 focus:outline-none focus:border-sky-500/40 min-h-[100px] resize-none leading-relaxed"
                    />
                  ) : (
                    <p className="text-gray-700 whitespace-pre-wrap leading-relaxed">
                      {entry.content}
                    </p>
                  )}
                  
                  {/* Decorative dot */}
                  <div className="absolute left-0 top-0 bottom-0 w-1 bg-transparent group-hover:bg-sky-500 transition-colors" />
                </div>
              ))}
            </div>
          )}
        </div>
      </main>
      
      {/* Footer hint */}
      <footer className="px-6 py-4 bg-gray-50/50 border-t border-gray-100 flex justify-center">
        <div className="flex items-center gap-2 text-[10px] font-bold text-gray-400 uppercase tracking-widest">
          <span>{entries.length} Total Entries</span>
          <span className="w-1 h-1 bg-gray-300 rounded-full" />
          <span>Encrypted with Supabase</span>
        </div>
      </footer>
    </div>
  );
};
