
import React from 'react';

interface InputFieldProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label: string;
  icon?: React.ReactNode;
}

export const InputField: React.FC<InputFieldProps> = ({ 
  label, 
  icon, 
  className, 
  ...props 
}) => {
  return (
    <div className="flex flex-col gap-2">
      <label className="text-sm font-medium text-gray-700">
        {label}
      </label>
      <div className="relative group">
        {icon && (
          <div className="absolute left-3.5 top-1/2 -translate-y-1/2 transition-colors group-focus-within:text-white">
            {icon}
          </div>
        )}
        <input
          {...props}
          className={`
            w-full py-3.5 rounded-xl bg-[#2D2D2D] text-white placeholder-gray-500 
            transition-all duration-200 outline-none
            ring-2 ring-transparent focus:ring-sky-500/20 focus:bg-[#353535]
            ${icon ? 'pl-11' : 'pl-4'} pr-4
            ${className}
          `}
        />
      </div>
    </div>
  );
};
