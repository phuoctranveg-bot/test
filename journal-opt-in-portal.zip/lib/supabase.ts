
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://ljaegppijdoxsuciiuqh.supabase.co';
const supabaseAnonKey = 'sb_publishable_MM23TXPEbzYBY7hF2UETUw_1EuLc4Sg';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
