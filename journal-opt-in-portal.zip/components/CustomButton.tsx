
import React from 'react';

interface CustomButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  children: React.ReactNode;
}

export const CustomButton: React.FC<CustomButtonProps> = ({ 
  children, 
  className, 
  disabled,
  ...props 
}) => {
  return (
    <button
      {...props}
      disabled={disabled}
      className={`
        w-full py-3.5 rounded-xl font-semibold text-white
        bg-sky-600 hover:bg-sky-700 active:bg-sky-800
        transition-all duration-200 
        shadow-lg shadow-sky-600/20 hover:shadow-sky-600/30
        disabled:opacity-70 disabled:cursor-not-allowed
        ${className}
      `}
    >
      {children}
    </button>
  );
};
