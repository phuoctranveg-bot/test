
import React, { useState } from 'react';
import { Lock, Mail, Loader2, UserPlus } from 'lucide-react';
import { InputField } from './InputField';
import { CustomButton } from './CustomButton';
import { supabase } from '../lib/supabase';

interface SignInCardProps {
  onToast: (message: string, type: 'success' | 'error') => void;
}

export const SignInCard: React.FC<SignInCardProps> = ({ onToast }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isSignUp, setIsSignUp] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) return;
    
    setIsLoading(true);
    
    try {
      if (isSignUp) {
        const { error } = await supabase.auth.signUp({
          email,
          password,
        });
        if (error) throw error;
        onToast('Account created! Please check your email to verify.', 'success');
      } else {
        const { error } = await supabase.auth.signInWithPassword({
          email,
          password,
        });
        if (error) throw error;
        onToast('Successfully signed in!', 'success');
      }
    } catch (error: any) {
      onToast(error.message || 'An unexpected error occurred', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="w-full max-w-md bg-white rounded-2xl shadow-xl p-8 sm:p-10 transition-all duration-300 hover:shadow-2xl">
      {/* Header Icon */}
      <div className="flex justify-center mb-6">
        <div className="w-14 h-14 bg-sky-50 rounded-full flex items-center justify-center border border-sky-100">
          {isSignUp ? (
            <UserPlus className="w-6 h-6 text-sky-500" />
          ) : (
            <Lock className="w-6 h-6 text-sky-500" />
          )}
        </div>
      </div>

      {/* Header Text */}
      <div className="text-center mb-8">
        <h1 className="text-2xl font-bold text-gray-900 mb-2">
          {isSignUp ? 'Create Account' : 'Welcome Back'}
        </h1>
        <p className="text-sm text-gray-500">
          {isSignUp ? 'Join our community to start journaling.' : 'Enter your credentials to access your journal.'}
        </p>
      </div>

      {/* Form */}
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="space-y-4">
          <InputField
            label="Email Address"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@example.com"
            icon={<Mail className="w-5 h-5 text-gray-400" />}
            required
          />

          <InputField
            label="Password"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="********"
            icon={<Lock className="w-5 h-5 text-gray-400" />}
            required
          />
        </div>

        <CustomButton type="submit" disabled={isLoading} className="mt-8">
          {isLoading ? (
            <div className="flex items-center justify-center gap-2">
              <Loader2 className="w-4 h-4 animate-spin" />
              <span>{isSignUp ? 'Creating Account...' : 'Signing In...'}</span>
            </div>
          ) : (
            isSignUp ? 'Sign Up' : 'Sign In'
          )}
        </CustomButton>
      </form>

      {/* Footer */}
      <div className="mt-8 text-center text-sm">
        <span className="text-gray-500">
          {isSignUp ? 'Already have an account? ' : "Don't have an account? "}
        </span>
        <button 
          onClick={() => setIsSignUp(!isSignUp)}
          className="text-sky-600 font-semibold hover:text-sky-700 transition-colors focus:outline-none focus:underline"
        >
          {isSignUp ? 'Sign in' : 'Sign up'}
        </button>
      </div>
    </div>
  );
};
